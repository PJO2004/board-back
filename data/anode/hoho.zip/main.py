from fastapi import FastAPI
import uvicorn
from fastapicreater import create_app
import routerho
from fastapi.staticfiles import StaticFiles
from starlette.responses import FileResponse
import os
from starlette_exporter import PrometheusMiddleware, handle_metrics

projectname = os.getenv("PROJECTNAME")
app: FastAPI = FastAPI(root_path=f"/{projectname}")
app: FastAPI = create_app(app)
app: FastAPI = routerho.include_router(app)
app.mount("/static", StaticFiles(directory="static"), name="static")
app.add_middleware(PrometheusMiddleware)
app.add_route("/metrics", handle_metrics)
FAVICON_PATH: str = "favicon.ico"


@app.get("/favicon.ico")
async def favicon() -> FileResponse:
    return FileResponse(FAVICON_PATH)


if __name__ == "__main__":
    if projectname:
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=8000,
            access_log=False,
            root_path=f"/{projectname}",
            reload=True,
        )
    else:
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=8000,
            access_log=False,
            reload=True,
        )

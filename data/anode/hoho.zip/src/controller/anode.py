import sys
import os
from fastapi import APIRouter, Request, Depends, status

sys.path.append(os.path.dirname(__file__))
sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
sys.path.append(
    os.path.dirname(os.path.abspath(os.path.dirname(os.path.abspath(os.path.dirname(__file__)))))
)
from vo.slotvo import RegisterMSG, DeploymentMSG
from vo import slotvo

anoderouter: APIRouter = APIRouter()


@anoderouter.post("/register", status_code=status.HTTP_201_CREATED)
def register(item: slotvo.RegisterMSG):
    return item


@anoderouter.post("/ssss", status_code=status.HTTP_201_CREATED)
def hogot(item: slotvo.HoModel):
    return item


@anoderouter.post("/deployment", status_code=status.HTTP_201_CREATED)
def deployment(item: slotvo.DeploymentMSG):
    return item


@anoderouter.get("/item/{item_id}", status_code=status.HTTP_201_CREATED)
def read_item(item_id: int):
    return {"item_id": item_id, "status": "true"}


@anoderouter.get("/")
async def root():
    return {"message": "Hello anode process"}

from pydantic import BaseModel, validator, create_model
from typing import Optional
import os
import json
from pydoc import locate

BASE_PATH: str = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
"""
"indir": "Kulas Light",
"outdir": "Apt. 556",
"inparam": ["1234","12345",1234],
"outparam": "92998-3874"
"""
HoModel = None


class DefalutModel(BaseModel):
    images: Optional[str] = None
    files: Optional[str] = None
    airpods: Optional[list] = None
    applewatch: Optional[str] = None


if os.path.exists(f"{BASE_PATH}/paramjson.json"):
    with open(f"{BASE_PATH}/paramjson.json", "r") as f:
        json_data: dict = json.load(f)

    def dictfinder(json_data: dict) -> dict:
        dict_value: dict = dict()
        for index, value in json_data.items():
            if value.get("type") == "dict":
                dict_value[index] = dictfinder(value.get("default"))
                # dict_value[index] = (locate(value.get("type")), dictfinder(value.get("default")))
            else:
                if value.get("default") is not None:
                    dict_value[index] = (locate(value.get("type")), value.get("default"))
                else:
                    dict_value[index] = (locate(value.get("type")), ...)
        return dict_value

    def dict_model(name: str, dict_def: dict):
        fields = {}
        for field_name, value in dict_def.items():
            if isinstance(value, tuple):
                fields[field_name] = value
            elif isinstance(value, dict):
                fields[field_name] = (dict_model(f"{name}_{field_name}", value), ...)
            else:
                raise ValueError(f"Field {field_name}:{value} has invalid syntax")
        return create_model(name, **fields)

    dictvalue: dict = dictfinder(json_data)
    HoModel: BaseModel = dict_model("HoModel", dictvalue)
else:
    HoModel = DefalutModel


class param(BaseModel):
    indir: Optional[str] = None
    outdir: Optional[str] = None
    inparam: Optional[list] = None
    outparam: Optional[str] = None


class RegisterMSG(BaseModel):
    id: str
    name: str
    token: Optional[str] = None
    classpath: str
    giturl: Optional[str] = None
    src: Optional[str] = None
    nas_mount_path_src: Optional[str] = None
    nas_mount_path_des: Optional[str] = None
    callback_url: str
    params: Optional[param] = None


class DeploymentMSG(BaseModel):
    id: str
    token: Optional[str] = None
    jobid: str
    reqdate: str
    indir: Optional[str] = None
    inparam: Optional[str] = None

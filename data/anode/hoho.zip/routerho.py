from fastapi import FastAPI


def include_router(app: FastAPI) -> FastAPI:
    from src.controller import anode

    app.include_router(anode.anoderouter, tags=["anode"])
    return app

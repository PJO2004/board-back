from fastapi import Request, Response
from fastapi.responses import JSONResponse
import logging
import logging.config
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi_jwt_auth.exceptions import MissingTokenError
from fastapi.responses import RedirectResponse

# status_reasons = {x.value:x.name for x in list(HTTPStatus)}

# def get_extra_info(request: Request, response: Response):
#     return {'req': {
#         'url': request.url.path,
#         'headers': {'host': request.headers['host'],
#                     'user-agent': request.headers['user-agent'],
#                     #'accept': request.headers['accept']
#                     },
#         'method': request.method,
#         'httpVersion': request.scope['http_version'],
#         'originalUrl': request.url.path,
#         'query': {}
#         },
#         'res': {'statusCode': response.status_code, 'body': {'statusCode': response.status_code,
#                    'status': status_reasons.get(response.status_code)}}}


def create_app(app):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request, exc):
        logging.error(str(exc.detail))
        return JSONResponse(
            status_code=exc.status_code,
            content={"message": str(exc.detail)},
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request, exc):
        logging.error(str(exc))
        return JSONResponse(
            status_code=400,
            content={"message": "There is no required value."},
        )

    @app.exception_handler(MissingTokenError)
    async def token_exception_handler(request, exc):
        logging.info("여기다요!")
        return RedirectResponse("/user/logins")

    # @app.exception_handler(ValueError)
    # async def value_error_exception_handler(request: Request, exc: ValueError):
    #     logging.error(str(exc))
    #     return JSONResponse(
    #         status_code=400,
    #         content={"message": "There is no required value."},
    # )

    @app.exception_handler(Exception)
    async def debug_exception_handler(request: Request, exc: Exception):
        import traceback

        errorcontent = "".join(
            traceback.format_exception(etype=type(exc), value=exc, tb=exc.__traceback__)
        )
        logging.error(errorcontent)
        return JSONResponse(
            status_code=400,
            content={"message": "Error"},
        )

    # @app.middleware("http")
    # async def log_request(request: Request, call_next):
    #     response = await call_next(request)
    #     # logging.info(request.method + ' ' + request.url.path +' '+ str(get_extra_info(request, response)))
    #     return response
    # 라우터 정의
    @app.on_event("startup")
    async def startup_event():
        logging.info("FastApi Start now!")

    @app.on_event("shutdown")
    async def startup_event():
        logging.info("FastApi Shutdown now!")

    return app
